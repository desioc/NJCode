module modulefx {
    requires javafx.controls;
    exports com.claudiodesio.javafx;
}